# วิธีสร้าง APK เวอร์ชัน Custom Prompt (ภาษาไทย)

แพ็กเกจนี้เพิ่มช่อง Custom Prompt หนึ่งช่องในหน้า Settings และบันทึกค่าไว้ในเครื่อง เมื่อเริ่มเซสชัน แอปจะส่งข้อความที่กรอกเป็น `systemInstruction` หากปล่อยว่างจะไม่เพิ่มคำสั่งพิเศษ

## วิธีที่แนะนำ: สร้าง APK บน GitHub Actions โดยไม่ติดตั้ง Android SDK ในมือถือ

1. สร้าง repository ใหม่บน GitHub และอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์ `live-translate-main` ไปยัง branch `main` (รวมโฟลเดอร์ `.github/workflows` ด้วย)
2. เปิดแท็บ **Actions** ของ repository
3. เลือก **Build Custom Prompt APK** แล้วกด **Run workflow** (หรือรอให้ workflow ทำงานหลัง push)
4. เปิดงานที่เสร็จแล้ว และดาวน์โหลด artifact ชื่อ `live-translate-custom-prompt-debug-apk`
5. แตก ZIP artifact แล้วติดตั้งไฟล์ APK บน Android

## ข้อจำกัด
- นี่คือ debug APK สำหรับทดสอบ ไม่ใช่ release build สำหรับเผยแพร่
- ต้องตรวจสอบการแปลจริงด้วย API key ของตนเอง เพราะการส่ง systemInstruction อาจมีผลต่างกันตามโมเดล/endpoint ที่ใช้งาน
- หาก workflow แจ้งว่า Android SDK platform/build-tools 37 ยังไม่มีใน runner ให้ปรับเวอร์ชันใน `app/build.gradle.kts` และ workflow ให้ตรงกัน
